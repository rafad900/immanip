#----------------------------------------------------------------
# Generated CMake target import file for configuration "Release".
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "immanip::immanip" for configuration "Release"
set_property(TARGET immanip::immanip APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(immanip::immanip PROPERTIES
  IMPORTED_LOCATION_RELEASE "${_IMPORT_PREFIX}/lib/x86_64-linux-gnu/libimmanip.so.0.1.0"
  IMPORTED_SONAME_RELEASE "libimmanip.so.0"
  )

list(APPEND _cmake_import_check_targets immanip::immanip )
list(APPEND _cmake_import_check_files_for_immanip::immanip "${_IMPORT_PREFIX}/lib/x86_64-linux-gnu/libimmanip.so.0.1.0" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)
